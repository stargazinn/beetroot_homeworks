with open('myfile.txt', 'r') as file:
    print(file.read())