with open('myfile.txt', 'w') as file:
    file.write("Hello file world")