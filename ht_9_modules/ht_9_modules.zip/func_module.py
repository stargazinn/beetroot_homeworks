
def euro_to_usd(euro):
    return euro * 1.08