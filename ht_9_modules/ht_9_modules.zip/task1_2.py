# # Task 1
# from func_module import euro_to_usd
#
# while True:
#     euro = input("How many euro would you like to exchange (press 'q' to quit): ")
#     if euro.lower() == 'q':
#         quit()
#     else:
#         dollar = euro_to_usd(int(euro))
#         print(f"You have {dollar} usd now!")
# # Task 2
# import sys
#
# print(sys.path)
# sys.path.append("La-la-la-la-la")
# print()
# print(sys.path)
# sys.path.clear()
# print()
# print(sys.path)
#
# """-------------Перевірка-------------"""
# from func_module import euro_to_usd
#
# print(euro_to_usd(100))
# """-------------Перевірка-------------"""
#
#

