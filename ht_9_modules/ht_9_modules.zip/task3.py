import mymod

# mymod.count_lines('test_file.txt')
# mymod.count_chars('test_file.txt')
mymod.test('D:\\beetroot\\ht_9_modules\\test_file.txt')

