#Task1
my_string = input("Enter your string: ")
if len(my_string) < 2:
    result = ""
else:
    result = my_string[:2] + my_string[-2:]
print(result)

#Task2
ph_number = "1234567890"
if len(ph_number) == 10 and ph_number.isdigit():
    print("Phone number is correct.")
else:
    print("Entered phone number is wrong.")

#Task3
while True:
    answer = int(input("What is 2 + 2 * 2?\nEnter your answer: "))
    if answer == 2 + 2 * 2:
        print("That's right!")
        break
    else:
        print("You are wrong! Try again... ")

#Task4
name = "volodymyr"
while True:
    my_name = input("Enter your name: ")
    if my_name.lower() == name:
        print(True)
        break

